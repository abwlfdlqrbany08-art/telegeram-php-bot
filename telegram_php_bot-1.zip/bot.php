<?php
$botToken = "8403544836:AAGKDV0_IlvcDFSgFxFfugB-bVWOFG4zp_g";
$website = "https://api.telegram.org/bot" . $botToken;
$update = file_get_contents("php://input");
$update = json_decode($update, TRUE);
if(!$update) exit;
$chatId = $update["message"]["chat"]["id"] ?? null;
$text = $update["message"]["text"] ?? "";
if ($text == "/start") {
    $reply = "سلام 👋 خوش اومدی به ربات من!";
    file_get_contents($website . "/sendMessage?chat_id=" . $chatId . "&text=" . urlencode($reply));
}
?>